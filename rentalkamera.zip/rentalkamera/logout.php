<?php

session_start();
session_uset();
session_destroy();

header("location:login.php?logout=sukses");