<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Tambah</h1>
    <form action="proses_tambah.php" method="POST">

        <label>Kode Kamera</label>
        <input type="number" name="kd_kamera"><br><br>

        <label>Kode Customer</label>
        <input type="number" name="kd_customer"><br><br>

        <label>Tanggal Pinjam</label>
        <input type="date" name="tgl_pinjam"><br><br>

        <label>Tanggal Kembali</label>
        <input type="date" name="tgl_kembali"><br><br>

        <input type="submit" value="simpan">
    </form>
</body>
</html>