<?php
session_start();
include "../koneksi.php";
$sql = "SELECT * FROM sewa";
$query = mysqli_query($koneksi, $sql);

if (!isset($_SESSION['login'])) {
    header("location:../login.php?pesan=logindulu");
    echo 'anda login sebagai' . $_SESSION['login'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">RENTAL KAMERA</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="../customer">Customer</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../kamera">Kamera</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../sewa">Sewa</a>
        </li>
        <form class="d-flex">
            <input class="form-control me-5m-2"  type="search" placeholder="Search">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
        </form>
    </div>
  </div>

</nav>
    <style>
        @media print{
            #cetak{
                display:none;
            }
        }
    </style>
    <title>Rental Kamera</title>
</head>
<body>
    <div class="container">
    <h1 align="center">Rental Kamera</h1>
    <a href="tambah.php"><button class="btn btn-secondary">Tambah</button></a><br><br>
    <a href="../logout.php"><button class="btn btn-success">LOGOUT</button></a><br><br>
    <table class = "table table-bordered">

        <tr class="table table-dark">

            <th>Kode Sewa</th>
            <th>Kode Kamera</th>
            <th>Kode Customer</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Total Sewa</th>
            <th>Aksi</th>
        </tr>
        <?php while ($sewa = mysqli_fetch_assoc($query)) { ?>
            <tr>
                <td><?=$sewa['kd_sewa'];?></td>
                <td><?=$sewa['kd_kamera'];?></td>
                <td><?=$sewa['kd_customer'];?></td>
                <td><?=$sewa['tgl_pinjam'];?></td>
                <td><?=$sewa['tgl_kembali'];?></td>
                <td><?=$sewa['total_sewa'];?></td>
                <td>
                    <a href="edit.php?kd_sewa=<?=$sewa['kd_sewa'];?>"><button id="cetak" class="btn btn-warning">Edit</button></a>
                    <a href="hapus.php?kd_sewa=<?=$sewa['kd_sewa'];?>"><button id="cetak" class="btn btn-danger">Hapus</button></a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table><br>
    <button id = "pr" class="btn btn-info" onclick="window.print()">CETAK</button></a>
</body>
</html>