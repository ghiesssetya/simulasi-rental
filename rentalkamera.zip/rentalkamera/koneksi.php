<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "rentalkamera";

$koneksi = mysqli_connect($server,$username,$password,$database);

// if($koneksi) {
//     echo "berhasil";
// }else{
//     echo "gagal";
// }

?>