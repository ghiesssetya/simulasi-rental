<?php
include "../koneksi.php";
$kd_sewa = $_GET['kd_sewa'];
$sql = "SELECT * FROM sewa WHERE kd_sewa = '$kd_sewa'";
$query = mysqli_query($koneksi, $sql);
while ($sewa = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="../haghies.css">
</head>
<body>
    <div class="text-center d-flex flex-column min-vh-100 justify-content-center align-items-center">
    <h1 class="m-4">Edit Form</h1>
    <form action="proses_edit.php" method="post">
        <input type="hidden" name="kd_sewa" value="<?=$sewa['kd_sewa']?>">
    <label for="">Kd Kamera</label>
    <input type="number" name="kd_kamera" id="" placeholder="kd kamera" class="form-control" value="<?=$sewa['kd_kamera']?>">
    
    <label for="">Kd Customer</label>
    <input type="number" name="kd_customer" id=""  placeholder="kd customer" class="form-control" value="<?=$sewa['kd_customer']?>">

    <label for="">Tanggal Pinjam</label>
    <input type="date" name="tgl_pinjam" id=""  placeholder="tanggal pinjam" class="form-control" value="<?=$sewa['tgl_pinjam']?>">

    <label for="">Tanggal Kembali</label>
    <input type="date" name="tgl_kembali" id=""  placeholder="tanggal kembali" class="form-control" value="<?=$sewa['tgl_kembali']?>"><br>

    <input type="submit" value="update" class="btn btn-outline-success form-control"><br><br>
    </form>
    <a href="index.php"><button class="btn btn-outline-secondary form-control">Back to Index</button></a>
    </div>
</body>
</html>
<?php
}
?>