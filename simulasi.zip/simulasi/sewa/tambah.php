<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add</title>
    <link rel="stylesheet" href="../haghies.css">
</head>
<body>
    <div class="text-center d-flex flex-column min-vh-100 justify-content-center align-items-center">
        <div class="card p-5">
    <h1 class ="m-4">Add Form</h1>
    <form action="proses_tambah.php" method="post">
   
    <input type="number" name="kd_kamera" id="" placeholder="Kd Kamera" class="form-control"><br>
    
    <input type="number" name="kd_customer" id="" placeholder="Kd Customer" class="form-control"><br>

    <input type="date" name="tgl_pinjam" id="" placeholder="Tanggal Pinjam" class="form-control"><br>

    <input type="date" name="tgl_kembali" id="" placeholder="Tanggal Kembali" class="form-control"><br>

    <input type="submit" value="save" class="btn btn-outline-success form-control"><br><br>
    
    
    </form>
    <a href="index.php"><button class="btn btn-outline-secondary">Back to Index</button></a><br>
    </div>
    </div>
</body>
</html>