<?php
$koneksi = mysqli_connect('localhost', 'root', '123456', 'rentalkamera');
// if ($koneksi) {
//     echo "okeedesuu";
// } else {
//     echo "gakbisaaa";
// }

?>