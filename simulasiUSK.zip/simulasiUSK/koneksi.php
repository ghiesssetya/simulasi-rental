<?php
$koneksi = mysqli_connect('localhost', 'root', '','kamera');
// if ($koneksi) {
//     echo "okeee";
// } else {
//     echo "gakbisaaa";
// }
?>