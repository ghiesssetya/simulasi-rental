<?php
include "koneksi.php";
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$sql = "SELECT * FROM user WHERE username = '$username' AND PASSWORD = md5('$password')";
$query = mysqli_query($koneksi, $sql);

if (mysqli_num_rows($query)>0) {
    
    $_SESSION['login']="admin";
    header ("location:sewa/index.php?login=okeeee");
} else {
    header ("location:login.php?login=gakbisaaa");
}
?>