<?php
include "../koneksi.php";
$kd_sewa = $_POST['kd_sewa'];

$kd_kamera = $_POST['kd_kamera'];
$kd_customer = $_POST['kd_customer'];
$tgl_pinjam = $_POST['tgl_pinjam'];
$tgl_kembali = $_POST['tgl_kembali'];

$diff = date_diff(date_create($tgl_pinjam),
date_create($tgl_kembali));
$hari = $diff->format("%a")+1;

$sql = "SELECT * FROM kamera WHERE kd_kamera='$kd_kamera'";
$query = mysqli_query($koneksi, $sql);
while ($kamera=mysqli_fetch_assoc($query)) {
$tarif = $kamera['tarif'];    
}
$total_sewa = $hari * $tarif;
echo $total_sewa;

$sql2 = "UPDATE sewa SET kd_kamera = '$kd_kamera', kd_customer = '$kd_customer', tgl_pinjam =  '$tgl_pinjam', 
tgl_kembali =  '$tgl_kembali', total_sewa = '$total_sewa' WHERE kd_sewa = '$kd_sewa'";  
$query2 = mysqli_query($koneksi, $sql2);

if ($query2) {
    header ("location:index.php?save=okeeee");
} else {
    header ("location:index.php?save=gakbisaaa");
}

?>