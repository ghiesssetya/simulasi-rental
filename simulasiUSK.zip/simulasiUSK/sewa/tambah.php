<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <title>Tambah</title>
</head>
<body>
    
    <h1 align="center">Tambah Data</h1>
    <form action="proses_tambah.php" method="post">
    <div class="d-flex flex-column min-vh-100 justify-content-center align-items-center">
        <div class="card p-5">
        
        <label for="">KD Kamera</label>
        <input type="number" name="kd_kamera" id=""><br>

        <label for="">KD Customer</label>
        <input type="number" name="kd_customer" id=""><br>

        <label for="">Tanggal Pinjam</label>
        <input type="date" name="tgl_pinjam" id=""><br>

        <label for="">Tanggal Kembali</label>
        <input type="date" name="tgl_kembali" id=""><br>

        <input type="submit" value="save" class="btn btn-primary"><br><br>
    
        </div>
        </div>
    </form>
</body>
</html>