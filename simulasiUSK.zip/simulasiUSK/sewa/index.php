<?php
session_start();
if(!isset($_SESSION["login"])){
    header ("location:../login.php?loginn=LoginDuluuu");
}
include "../koneksi.php";
$sql = "SELECT * FROM sewa";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <title>Data Kamera</title>
    
    <style>
        @media print {
            #cetak{
                display:none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
    <h1 align = "center">Data Kamera</h1>
    <a href="tambah.php"><button id = "cetak" class="btn btn-info mx-1">Add</button></a>
    <button id="cetak" onclick="window.print()" class="btn btn-info mx-1">Print</button>
    <table class=table>
        <tr class="table-dark">
            <th>KD SEWA</th>
            <th>KD KAMERA</th>
            <th>KD CUSTOMER</th>
            <th>TANGGAL PINJAM</th>
            <th>TANGGAL KEMBALI</th>
            <th>TOTAL SEWA</th>
            <th  id="cetak" class="text-center">ACTION</th>
        </tr>
        <?php
        while($sewa=mysqli_fetch_assoc($query)){
            ?>
            <tr>
                <td><?=$sewa['kd_sewa']?></td>
                <td><?=$sewa['kd_kamera']?></td0>
                <td><?=$sewa['kd_customer']?></td>
                <td><?=$sewa['tgl_pinjam']?></td>
                <td><?=$sewa['tgl_kembali']?></td>
                <td><?=$sewa['total_sewa']?></td>
                <td class="text-center">
                    <a href="hapus.php?kd_sewa=<?=$sewa['kd_sewa']?>"><button id="cetak" class="btn btn-danger">Delete</button></a>
                    <a href="edit.php?kd_sewa=<?=$sewa['kd_sewa']?>"><button id="cetak" class="btn btn-warning">Edit</button></a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
    <a href="../login.php"><button id="cetak" class="btn btn-danger">Logout</button></a>
    </div>
</body>
</html>
