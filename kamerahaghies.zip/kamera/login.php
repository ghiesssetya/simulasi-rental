<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
    <title>LOGIN</title>
</head>
<body>
    <div class="d-flex flex-column min-vh-100 justify-content-center align-items-center">
    <div class="card p-5">
    <h1 align="center">LOGIN</h1>
    <form action="proses_login.php" method="post">
        <input type="text" name="username" placeholder="username" id=""><br>
        <input type="password" name="password" placeholder="password" id=""><br><br>
        <input type="submit" value="Login" class="btn btn-primary"><br>
    </form>
    </div>
    </div>
</body>
</html>
