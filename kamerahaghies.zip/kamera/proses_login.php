<?php
include "koneksi.php";
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$sql = "SELECT * FROM user WHERE username ='$username'
AND PASSWORD = md5('$password')";
$query = mysqli_query($koneksi,$sql);
if (mysqli_num_rows($query)) {
    $_SESSION['login'] = '$username';
    header ("location:../kamera/sewa/index.php?login=sukses");
} else {
    header ("location:login.php?login=gakbisaaa");
}
?>