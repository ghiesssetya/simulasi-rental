<?php
session_start();
if(!isset($_SESSION['login'])){
    header ("location:../login.php?haruslogindulu");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <title>ADD</title>
</head>
<body>
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center">
    <div class="card p-5">
    <h1 align="center">Add Form</h1>
    <a href="index.php"><button class="btn btn-secondary">Back to Index</button></a><br><br>
    <form action="proses_tambah.php" method="post">
        <input type="number" name="kd_kamera" placeholder="KD Kamera" id=""><br>
        <input type="number" name="kd_customer" placeholder="KD Customer" id=""><br>
        <input type="date" name="tgl_pinjam" placeholder="Tanggal Pinjam" id=""><br>
        <input type="date" name="tgl_kembali" placeholder="Tanggal Kembali" id=""><br><br>
        <input type="submit" value="Add" class="btn btn-primary">
    </div>
    </div>
    </form>
</body>
</html>