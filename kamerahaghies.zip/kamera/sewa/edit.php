<?php
session_start();
if(!isset($_SESSION['login'])){
    header ("location:../login.php?haruslogindulu");
}
include "../koneksi.php";
$kd_sewa =  $_GET['kd_sewa'];
$sql = "SELECT * FROM sewa WHERE kd_sewa='$kd_sewa'";
$query = mysqli_query($koneksi,$sql);
while ($sewa=mysqli_fetch_assoc($query)) {
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <title>EDIT</title>
</head>
<body>
<div class="d-flex flex-column min-vh-100 justify-content-center align-items-center">
    <div class="card p-5">
    <h1 align="center">Edit Form</h1>
    <a href="index.php"><button class="btn btn-secondary">Back to Index</button></a><br><br>
    <form action="proses_edit.php" method="post">
    <input type="hidden" name="kd_sewa" value="<?=$sewa['kd_sewa']?>">    
    <label for="">KD Kamera</label>
        <input type="number" name="kd_kamera" placeholder="KD Kamera" id="" value="<?=$sewa['kd_kamera']?>"><br>
        <label for="">KD Customer</label>
        <input type="number" name="kd_customer" placeholder="KD Customer" id="" value="<?=$sewa['kd_customer']?>"><br>
        <label for="">Tanggal Pinjam</label>
        <input type="date" name="tgl_pinjam" placeholder="Tanggal Pinjam" id="" value="<?=$sewa['tgl_pinjam']?>"><br>
        <label for="">Tanggal Kembali</label>
        <input type="date" name="tgl_kembali" placeholder="Tanggal Kembali" id="" value="<?=$sewa['tgl_kembali']?>"><br><br>
        <input type="submit" value="Update" class="btn btn-primary">
</div>
</div>
    </form>
</body>
</html>
<?php
}
?>