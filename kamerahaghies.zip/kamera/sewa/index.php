<?php
session_start();
if(!isset($_SESSION['login'])){
    header ("location:login.php?haruslogindulu");
}

include "../koneksi.php";
$sql = "SELECT * FROM sewa";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <style>
        @media  print{
            #cetak{
                display: none;
            }
        }
    </style>
    <title>Index</title>
</head>
<body>
    <div class="container">
    <h1 align ="center">RENTAL KAMERA</h1>
    <a href="tambah.php"><button id="cetak" class="btn btn-primary">Add</button></a>
    <button id="cetak" onclick="window.print()" class="btn btn-primary">Print</button><br><br>
    <table class="table">
        <tr class="table-info">
            <th class="text-center">Kd Sewa</th>
            <th class="text-center">Kd Kamera</th>
            <th class="text-center">Kd Customer</th>
            <th class="text-center">Tanggal Pinjam</th>
            <th class="text-center">Tanggal Kembali</th>
            <th class="text-center">Total Sewa</th>
            <th id="cetak" class="text-center">Action</th>
        </tr>
        <?php
        while ($sewa=mysqli_fetch_assoc($query)) {
            ?>
            <tr>
                <td class="text-center"><?=$sewa['kd_sewa']?></td>
                <td class="text-center"><?=$sewa['kd_kamera']?></td>
                <td class="text-center"><?=$sewa['kd_customer']?></td>
                <td class="text-center"><?=$sewa['tgl_pinjam']?></td>
                <td class="text-center"><?=$sewa['tgl_kembali']?></td>
                <td class="text-center"><?=$sewa['total_sewa']?></td>
                <td class="text-center">
                    <a href="edit.php?kd_sewa=<?=$sewa['kd_sewa']?>"><button id="cetak"  class="btn btn-warning">Update</button></a>
                    <a href="hapus.php?kd_sewa=<?=$sewa['kd_sewa']?>"><button id="cetak" class="btn btn-danger">Delete</button></a>
                </td>
            </tr>
         <?php
        }
        ?>
    </table>
    <a href="../login.php"><button id="cetak" class="btn btn-outline-danger">Logout</button></a>    
    </div>
</body>
</html>