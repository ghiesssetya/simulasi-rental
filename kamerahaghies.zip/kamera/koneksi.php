<?php
$koneksi = mysqli_connect('localhost','root','','simulasirental');
// if ($koneksi) {
//     echo "okedesu";
// } else {
//     echo "gakbisaaa";
// }
?>